# smallBixTools
a few small functions for bioinformatics
