def main():
    print("in init of smallBixTools")
